/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.user_management.api;

import com.encentral.test_project.commons.exceptions.ResourceNotFound;
import com.encentral.test_project.entities.JpaCar;
import java.util.List;

/**
 *
 * @author James Akinniranye
 */
public interface CarService {
    
    JpaCar find(String carId) throws ResourceNotFound;
    List<JpaCar> findcarbylicense(String licenseplate) throws ResourceNotFound;
    List<JpaCar> findcarbycarname(String car) throws ResourceNotFound;
    List<JpaCar> findcarbyrating(String rating) throws ResourceNotFound;
    List<JpaCar> findcarbyseatcount(String seatcount) throws ResourceNotFound;
    List<JpaCar> findcarbyseatconvertible(String convertible) throws ResourceNotFound;
    List<JpaCar> findcarbyseatmanufacturer(String manufacturer) throws ResourceNotFound;
    List<JpaCar> findcarbyseatengine(String engine) throws ResourceNotFound;
    List<JpaCar> findallcar() throws ResourceNotFound;

    JpaCar create(JpaCar carDO) ;

    void delete(String carId) throws ResourceNotFound;

}
