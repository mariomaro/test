/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "carslot")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "JpaCarslot.findAll", query = "SELECT j FROM JpaCarslot j")})
public class JpaCarslot implements Serializable {

    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 64)
    @Column(name = "car_id", nullable = false, length = 64)
    private String carslotId;

    @Column(nullable = false)
    @Size(min = 1, max = 25)
    @NotNull(message = "car name can not be null!")
    private String cname;

    @Column(nullable = false, name = "avalaibility")
    @NotNull(message = "avalaibility plate can not be null!")
    @Size(min = 5)
    private String avalaibility;
    
    @Column(nullable = false, name = "driverid")
    @NotNull(message = "driver id can not be null!")
    @Size(min = 5)
    private String driverid;
    

    public String getCarslotId() {
        return carslotId;
    }

    public void setCarslotId(String carslotId) {
        this.carslotId = carslotId;
    }

    public String getCname() {
        return cname;
    }
    
    public void setCname(String cname) {
        this.cname = cname;
    }
    
    public String getAvalaibility() {
        return avalaibility;
    }
    
    public void setAvalaibility(String avalaibility) {
        this.avalaibility = avalaibility;
    }
    
    public String getDriverid() {
        return driverid;
    }
    
    public void setDriverid(String driverid) {
        this.driverid = driverid;
    }
    

}
