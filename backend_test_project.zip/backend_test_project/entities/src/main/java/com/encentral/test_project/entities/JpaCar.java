/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "car")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "JpaCar.findAll", query = "SELECT j FROM JpaCar j")})
public class JpaCar implements Serializable {

    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 64)
    @Column(name = "car_id", nullable = false, length = 64)
    private String carId;

    @Column(nullable = false)
    @Size(min = 1, max = 25)
    @NotNull(message = "car name can not be null!")
    private String cname;

    @Column(nullable = false,  name = "licenseplate")
    @NotNull(message = "license plate can not be null!")
    @Size(min = 5)
    private String licenseplate;
    
    @Column(nullable = false, name = "rating")
    @NotNull(message = "rating can not be null!")
    @Size(min = 1)
    private String rating;
    
    @Column(nullable = false, name = "seatcount")
    @NotNull(message = "seat count can not be null!")
    @Size(min = 1)
    private String seatcount;
    
    @Column(nullable = false, name = "convertible")
    @NotNull(message = "convertible can not be null!")
    @Size(min = 1)
    private String convertible;
    
    @Column(nullable = false, name = "manufacturer")
    @NotNull(message = "manufacturer can not be null!")
    @Size(min = 5)
    private String manufacturer;

    @Column(nullable = false, name = "engine")
    @NotNull(message = "engine can not be null!")
    @Size(min = 2)
    private String engine;


    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public String getCname() {
        return cname;
    }
    
    public void setCname(String cname) {
        this.cname = cname;
    }
    
    public String getLicenseplate() {
        return licenseplate;
    }
    
    public void setLicenseplate(String licenseplate) {
        this.licenseplate = licenseplate;
    }
    
    public String getRating() {
        return rating;
    }
    
    public void setRating(String rating) {
        this.rating = rating;
    }
    
    public String getSeatcount() {
        return seatcount;
    }
    
    public void setSeatcount(String seatcount) {
        this.seatcount = seatcount;
    }
    
    public String getConvertible() {
        return convertible;
    }
    
    public void setConvertible(String convertible) {
        this.convertible = convertible;
    }
    
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }
    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getEngine() {
        return engine;
    }


}
