/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.encentral.test_project.commons.exceptions.ResourceNotFound;
import com.encentral.test_project.commons.models.CarDTO;
import com.encentral.test_project.commons.models.CarMapper;
import com.encentral.test_project.commons.util.MyObjectMapper;
import com.encentral.test_project.entities.JpaCar;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.List;

import com.encentral.test_project.user_management.api.CarService;
import javax.inject.Inject;
import play.data.Form;
import play.data.FormFactory;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.*;
import static play.mvc.Results.badRequest;

/**
 *
 * @author poseidon
 */
@Api(value = "Car")
@Transactional
public class CarController extends Controller {

    @Inject
    FormFactory formFactory;

    @Inject
    MyObjectMapper objectMapper;

    @Inject
    CarService carService;

    @ApiOperation(value = "Get Car", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result getCar(String carId) {
        try {
            return ok(Json.toJson(CarMapper.jpaCarToCarDTO(carService.find(carId))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get all Car", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result getallCar() {
        try {
            return ok(Json.toJson((carService.findallcar())));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    
    
    @ApiOperation(value = "Get the Car by license", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarbylicense(String license) {
        try {
            return ok(Json.toJson((carService.findcarbylicense(license))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get the Car by carname", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarbycarname(String carname) {
        try {
            return ok(Json.toJson((carService.findcarbycarname(carname))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get the Car by rating", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarbyrating(String rating) {
        try {
            return ok(Json.toJson((carService.findcarbyrating(rating))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get the Car by seatcount", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarrbyseatcount(String seatcount) {
        try {
            return ok(Json.toJson((carService.findcarbyseatcount(seatcount))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get the Car by convertible", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarbyconvertible(String convertible) {
        try {
            return ok(Json.toJson((carService.findcarbyseatconvertible(convertible))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get the Car by manufacture", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarbymanufacture(String manufacture) {
        try {
            return ok(Json.toJson((carService.findcarbyseatmanufacturer(manufacture))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }
    @ApiOperation(value = "Get the Car by engine", notes = "", httpMethod = "GET")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done", response = CarDTO.class)
            }
    )
    public Result gettheCarbyengine(String engine) {
        try {
            return ok(Json.toJson((carService.findcarbyseatengine(engine))));
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
    }

    @ApiOperation(value = "Create a Car", notes = "", httpMethod = "POST")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done")
            }
    )
    @ApiImplicitParams(
            {
                @ApiImplicitParam(
                        name = "Application",
                        dataType = "com.encentral.test_project.commons.models.CarDTO",
                        required = true,
                        paramType = "body",
                        value = "Application"
                )
            }
    )
    public Result createCar() {
        Form<CarDTO> bindFromRequest = formFactory.form(CarDTO.class).bindFromRequest();

        JpaCar create = carService.create(CarMapper.carDTOtoJpaCar(bindFromRequest.get()));

        return ok(Json.toJson(CarMapper.jpaCarToCarDTO(create)));
    }

    @ApiOperation(value = "Delete Car", notes = "", httpMethod = "DELETE")
    @ApiResponses(
            value = {
                @ApiResponse(code = 200, message = "Done")
            }
    )
    public Result deleteCar(String carId) {
        try {
            carService.delete(carId);
            return noContent();
        } catch (ResourceNotFound ex) {
            return notFound(ex.getMessage());
        }
       
    }

}

