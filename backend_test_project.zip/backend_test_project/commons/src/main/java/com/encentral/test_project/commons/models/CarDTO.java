package com.encentral.test_project.commons.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CarDTO {

    private String carId;

    @NotNull(message = "car name can not be null!")
    @Size(min = 5)
    private String cname;

    @NotNull(message = "license plate can not be null!")
    @Size(min = 5)
    private String licenseplate;

    @NotNull(message = "rating can not be null!")
    @Size(min = 1)
    private String rating;

    @NotNull(message = "seat count can not be null!")
    @Size(min = 1)
    private String seatcount;
    
    @NotNull(message = "convertible can not be null!")
    @Size(min = 5)
    private String convertible;
    
    @NotNull(message = "manufacturer can not be null!")
    @Size(min = 5)
    private String manufacturer;
    
    
    @NotNull(message = "engine can not be null!")
    @Size(min = 5)
    private String engine;


    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public String getCname() {
        return cname;
    }
    
    public void setCname(String cname) {
        this.cname = cname;
    }
    
    public String getLicenseplate() {
        return licenseplate;
    }
    
    public void setLicenseplate(String licenseplate) {
        this.licenseplate = licenseplate;
    }
    
    public String getRating() {
        return rating;
    }
    
    public void setRating(String rating) {
        this.rating = rating;
    }
    
    public String getSeatcount() {
        return seatcount;
    }
    
    public void setSeatcount(String seatcount) {
        this.seatcount = seatcount;
    }
    
    public String getConvertible() {
        return convertible;
    }
    
    public void setConvertible(String convertible) {
        this.convertible = convertible;
    }
    
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }
    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getEngine() {
        return engine;
    }

}