/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.commons.models;

import com.encentral.test_project.entities.JpaCar;

/**
 *
 * @author James Akinniranye
 */
public class CarMapper {

    public static CarDTO jpaCarToCarDTO(JpaCar jpaCar) {
        CarDTO dTO = new CarDTO();
        dTO.setConvertible(jpaCar.getConvertible());
        dTO.setManufacturer(jpaCar.getManufacturer());
        dTO.setCarId(jpaCar.getCarId());
        dTO.setCname(jpaCar.getCname());
        dTO.setLicenseplate(jpaCar.getLicenseplate());
        dTO.setRating(jpaCar.getRating());
        dTO.setSeatcount(jpaCar.getSeatcount());
        dTO.setEngine(jpaCar.getEngine());
        return dTO;
    }

    public static JpaCar carDTOtoJpaCar(CarDTO dTO) {
        JpaCar jpaCar = new JpaCar();
        jpaCar.setConvertible(dTO.getConvertible());
        jpaCar.setManufacturer(dTO.getManufacturer());
        jpaCar.setCarId(dTO.getCarId());
        jpaCar.setCname(dTO.getCname());
        jpaCar.setLicenseplate(dTO.getLicenseplate());
        jpaCar.setRating(dTO.getRating());
        jpaCar.setSeatcount(dTO.getSeatcount());
        jpaCar.setEngine(dTO.getEngine());
        return jpaCar;
    }
}
