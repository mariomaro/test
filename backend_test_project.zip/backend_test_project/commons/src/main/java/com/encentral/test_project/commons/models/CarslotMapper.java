/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.commons.models;

import com.encentral.test_project.entities.JpaCarslot;

/**
 *
 * @author James Akinniranye
 */
public class CarslotMapper {

    public static CarslotDTO jpaCarslotToCarslotDTO(JpaCarslot jpaCarslot) {
        CarslotDTO dTO = new CarslotDTO();
        dTO.setCarslotId(jpaCarslot.getCarslotId());
        dTO.setCname(jpaCarslot.getCname());
        dTO.setAvalaibility(jpaCarslot.getAvalaibility());
        dTO.setDriverid(jpaCarslot.getDriverid());
        return dTO;
    }

    public static JpaCarslot carslotDTotoJpaCarslot(CarslotDTO dTO) {
        JpaCarslot jpaCarslot = new JpaCarslot();
        jpaCarslot.setCarslotId(dTO.getCarslotId());
        jpaCarslot.setCname(dTO.getCname());
        jpaCarslot.setAvalaibility(dTO.getAvalaibility());
        jpaCarslot.setDriverid(dTO.getDriverid());
        return jpaCarslot;
    }
}
