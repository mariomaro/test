package com.encentral.test_project.commons.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CarslotDTO {

    private String carslotId;

    @NotNull(message = "car name can not be null!")
    @Size(min = 5)
    private String cname;

    @NotNull(message = "avalaibility can not be null!")
    @Size(min = 5)
    private String avalaibility;

    @NotNull(message = "driverid can not be null!")
    @Size(min = 5)
    private String driverid;

   

    public String getCarslotId() {
        return carslotId;
    }

    public void setCarslotId(String carslotId) {
        this.carslotId = carslotId;
    }

    public String getCname() {
        return cname;
    }
    
    public void setCname(String cname) {
        this.cname = cname;
    }
    
    public String getAvalaibility() {
        return avalaibility;
    }
    
    public void setAvalaibility(String avalaibility) {
        this.avalaibility = avalaibility;
    }
    
    public String getDriverid() {
        return driverid;
    }
    
    public void setDriverid(String driverid) {
        this.driverid = driverid;
    }
    

    
}
