/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.commons.exceptions;

/**
 *
 * @author poseidon
 */
public class LoginAttemptExcededException extends Exception {

    public LoginAttemptExcededException(String mesStri) {
        super(mesStri);
    }
}
