rm -rf ~/.ivy2/cache/com.encentral.test_project/
sbt clean universal:packageZipTarball
