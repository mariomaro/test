
insert into driver (driver_id, date_created, deleted, online_status, password, username) values ('1', now(), false, 'OFFLINE','driver01pw','driver01');

