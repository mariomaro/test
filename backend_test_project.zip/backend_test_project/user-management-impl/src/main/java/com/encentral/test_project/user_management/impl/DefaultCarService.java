/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.user_management.impl;

import com.encentral.test_project.commons.exceptions.ResourceNotFound;
import com.encentral.test_project.entities.JpaCar;
import com.encentral.test_project.user_management.api.CarService;
import java.util.Date;
import javax.inject.Inject;
import play.db.jpa.JPAApi;
import java.util.List;

/**
 *
 * @author James Akinniranye
 */
public class DefaultCarService implements CarService {

    @Inject
    JPAApi jPAApi;

    @Override
    public JpaCar find(String carId) throws ResourceNotFound {
    	JpaCar Car = jPAApi.em().find(JpaCar.class, carId);
        if (Car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", carId));
        }
        return Car;
    }
    @Override
    public List<JpaCar> findallcar() throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a")
                .getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with not found"));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbylicense(String licenseplate) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.licenseplate = :licenseplate")
                .setParameter("licenseplate", licenseplate).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", licenseplate));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbycarname(String carname) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.cname = :carname")
                .setParameter("carname", carname).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", carname));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbyrating(String rating) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.rating = :rating")
                .setParameter("rating", rating).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", rating));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbyseatcount(String seatcount) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.seatcount = :seatcount")
                .setParameter("seatcount", seatcount).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", seatcount));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbyseatconvertible(String convertible) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.convertible = :convertible")
                .setParameter("convertible", convertible).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", convertible));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbyseatmanufacturer(String manufacturer) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.manufacturer = :manufacturer")
                .setParameter("manufacturer", manufacturer).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", manufacturer));
        }
        return car;
    }
    @Override
    public List<JpaCar> findcarbyseatengine(String engine) throws ResourceNotFound {
    	List<JpaCar> car = jPAApi.em().createQuery("SELECT a FROM JpaCar a where a.engine = :engine")
                .setParameter("engine", engine).getResultList();
        if (car == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", engine));
        }
        return car;
    }

    @Override
    public JpaCar create(JpaCar carDO) {
        carDO.setCarId(java.util.UUID.randomUUID().toString());
        jPAApi.em().persist(carDO);
        return carDO;
    }

    @Override
    public void delete(String carID) throws ResourceNotFound {
        jPAApi.em().detach(find(carID));
    }

}
