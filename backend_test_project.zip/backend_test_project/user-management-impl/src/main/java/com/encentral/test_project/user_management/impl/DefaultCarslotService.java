/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.user_management.impl;

import com.encentral.test_project.commons.exceptions.ResourceNotFound;
import com.encentral.test_project.entities.JpaCarslot;
import com.encentral.test_project.entities.JpaDriver;
import com.encentral.test_project.user_management.api.CarslotService;
import java.util.Date;
import javax.inject.Inject;
import play.db.jpa.JPAApi;

/**
 *
 * @author James Akinniranye
 */
public class DefaultCarslotService implements CarslotService {

    @Inject
    JPAApi jPAApi;

    @Override
    public JpaCarslot find(String carslotID) throws ResourceNotFound {
    	JpaCarslot Carslot = jPAApi.em().find(JpaCarslot.class, carslotID);
        if (Carslot == null) {
            throw new ResourceNotFound(String.format("Car Available with id %s ", carslotID));
        }
        return Carslot;
    }

    @Override
    public JpaCarslot create(JpaCarslot carDO) {
        carDO.setCarslotId(java.util.UUID.randomUUID().toString());
        jPAApi.em().persist(carDO);
        return carDO;
    }
    


    @Override
    public void delete(String carslotID) throws ResourceNotFound {
        jPAApi.em().detach(find(carslotID));
    }

}
