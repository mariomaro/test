/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.encentral.test_project.user_management.impl;

import com.encentral.test_project.commons.exceptions.ResourceNotFound;
import com.encentral.test_project.entities.JpaDriver;
import com.encentral.test_project.user_management.api.DriverService;
import java.util.Date;
import javax.inject.Inject;
import play.db.jpa.JPAApi;
import java.util.List;

/**
 *
 * @author James Akinniranye
 */
public class DefaultDriverService implements DriverService {

    @Inject
    JPAApi jPAApi;

    @Override
    public JpaDriver find(String username) throws ResourceNotFound {
        JpaDriver driver = jPAApi.em().find(JpaDriver.class, username);
        if (driver == null) {
            throw new ResourceNotFound(String.format("Driver with id %s not found", username));
        }
        return driver;
    }
    @Override
    public List<JpaDriver> finddriver(String username) throws ResourceNotFound {
    	List<JpaDriver> driver = jPAApi.em().createQuery("SELECT a FROM JpaDriver a where a.username = :username")
                .setParameter("username", username).getResultList();
        if (driver == null) {
            throw new ResourceNotFound(String.format("Driver with id %s not found", username));
        }
        return driver;
    }
    @Override
    public List<JpaDriver> finddriverbycar(String car) throws ResourceNotFound {
    	List<JpaDriver> driver = jPAApi.em().createQuery("SELECT a FROM JpaDriver a where a.cname = :car")
                .setParameter("car", car).getResultList();
        if (driver == null) {
            throw new ResourceNotFound(String.format("Car with id %s not found", car));
        }
        return driver;
    }
    @Override
    public List<JpaDriver> findalldriver() throws ResourceNotFound {
    	List<JpaDriver> driver = jPAApi.em().createQuery("SELECT a FROM JpaDriver a")
                .getResultList();
        if (driver == null) {
            throw new ResourceNotFound(String.format("Driver with not found"));
        }
        return driver;
    }
    @Override
    public JpaDriver create(JpaDriver driverDO) {
        driverDO.setDriverId(java.util.UUID.randomUUID().toString());
        driverDO.setDateCreated(new Date());
        jPAApi.em().persist(driverDO);
        return driverDO;
    }

    @Override
    public void delete(String driverId) throws ResourceNotFound {
        jPAApi.em().detach(find(driverId));
    }

}
